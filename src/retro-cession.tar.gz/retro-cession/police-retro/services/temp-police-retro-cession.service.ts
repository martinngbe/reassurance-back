import {
  Injectable,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TempPoliceRetroCession } from '../entities/temp-police-retro-cession.entity';
import { CrudService } from 'src/common/crud/crud.service';

@Injectable()
export class TempPoliceRetroCessionService extends CrudService<TempPoliceRetroCession> {
  constructor(
    @InjectRepository(TempPoliceRetroCession) repository: Repository<TempPoliceRetroCession>,
   
  ) {
    super(repository);
  }

 
}