import {
  Injectable,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PoliceRetroCession } from '../entities/police-retro-cession.entity';
import { CrudService } from 'src/common/crud/crud.service';

@Injectable()
export class PoliceRetroCessionService extends CrudService<PoliceRetroCession> {
  constructor(
    @InjectRepository(PoliceRetroCession) repository: Repository<PoliceRetroCession>,
   
  ) {
    super(repository);
  }

 
}