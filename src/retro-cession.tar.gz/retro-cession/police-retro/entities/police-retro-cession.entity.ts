import {  Column, Entity, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { NatureOffre } from 'src/referentiel/entities/nature-offre.entity';
import { Quittance } from 'src/quittances/entities/quittance.entity';
import { Acteur } from 'src/acteurs/entities/acteur.entity';
import { BrancheRetroCession } from 'src/referentiel/entities/branche-retro-cession.entity';
import { BaseEntity } from 'src/common/entities/base.entity';
import { QuittanceRetroCession } from 'src/retro-cession/quittance-retro-cession/entities/quittance-retro-cession.entity';

/**
 * Police d'assurance cédée en réassurance (acceptation ou cession selon
 * isCession). Rattachée à une sous-branche, à la cédante, au courtier
 * éventuel et à l'assuré.
 */
@Entity('police_retro_cession')
export class PoliceRetroCession extends BaseEntity {
  @Column({nullable:true})
  numero!: string;

  // @Column({ name: 'is_reconduction_tacite', default: false })
  // isReconductionTacite!: boolean;

  @Column({ name: 'is_iard', default: false })
  isIard!: boolean; // IARD | VIE

  // FAC | TRAITE  
  // On veut reduire le nombre de jointure
  // cette information peut être lu dans NatureOffre
  // @Column({ name: 'is_fac', default: false })
  // isFac!: boolean; // FAC | TRAITE

  // @Column({ name: 'is_cession', default: false })
  // isCession!: boolean;  //  CESSION | ACCEPTATION


  @OneToMany(() => QuittanceRetroCession, (quittance) => quittance.policeRetrocession , { cascade:true})
  quittancesRectroCessions!: QuittanceRetroCession[];

 

  @ManyToOne(() => NatureOffre , {eager:true})
  @JoinColumn({ name: 'nature_offre_id'  })
  natureOffre!: NatureOffre;
  @Column({ name: 'nature_offre_id' })
  natureOffreId!: number;


  // Relation BrancheCession
  @ManyToOne(() => BrancheRetroCession, {eager:true })
  @JoinColumn({ name: 'branche_retro_cession_id' })
  brancheCession!: BrancheRetroCession;
  @Column({ name: 'branche_retro_cession_id' })
  brancheCessionId!: number;


    // Relation Cedente
  @ManyToOne(() => Acteur, {eager:true , nullable:true})
  @JoinColumn({ name: 'acteur_reassureur_id' })
  acteurReassureur!: Acteur;
  @Column({ name: 'acteur_reassureur_id' , nullable:true})
  acteurReassureurId!: number;


// Relation courtier
  @ManyToOne(() => Acteur, {  eager:true , nullable:true})
  @JoinColumn({ name: 'acteur_courtier_id' })
  acteurCourtier?: Acteur;
  @Column({ name: 'acteur_courtier_id', nullable: true })
  acteurCourtierId?: number;

}
