import { Column, Entity, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { NatureOffre } from 'src/referentiel/entities/nature-offre.entity';
import { Quittance } from 'src/quittances/entities/quittance.entity';
import { BaseEntity } from 'src/common/entities/base.entity';
import { BrancheRetroCession } from 'src/referentiel/entities/branche-retro-cession.entity';
import { Acteur } from 'src/acteurs/entities/acteur.entity';

/**
 * Police d'assurance cédée en réassurance (acceptation ou cession selon
 * isCession). Rattachée à une sous-branche, à la cédante, au courtier
 * éventuel et à l'assuré.
 */
@Entity('temp_police_cession')
export class TempPoliceRetroCession extends BaseEntity {
  @Column({nullable:true})
  numero!: string;

  // @Column({ name: 'is_reconduction_tacite', default: false })
  // isReconductionTacite!: boolean;

  @Column({ name: 'is_iard', default: false })
  isIard!: boolean; // IARD | VIE

  // FAC | TRAITE  
  // On veut reduire le nombre de jointure
  // cette information peut être lu dans NatureOffre
  // @Column({ name: 'is_fac', default: false })
  // isFac!: boolean; // FAC | TRAITE

  // @Column({ name: 'is_cession', default: false })
  // isCession!: boolean;  //  CESSION | ACCEPTATION


  @OneToMany(() => Quittance, (quittance) => quittance.police , { cascade:true})
  quittances!: Quittance[];

 

  @ManyToOne(() => NatureOffre , {eager:true})
  @JoinColumn({ name: 'nature_offre_id'  })
  natureOffre!: NatureOffre;
  @Column({ name: 'nature_offre_id' })
  natureOffreId!: number;


  // Relation BrancheCession
  @ManyToOne(() => BrancheRetroCession, {eager:true })
  @JoinColumn({ name: 'branche_retro_cession_id' })
  brancheRetroCession!: BrancheRetroCession;
  @Column({ name: 'branche_retro_cession_id' })
  brancheRetroCessionId!: number;




    // Relation Cedente
  @ManyToOne(() => Acteur, {eager:true , nullable:true})
  @JoinColumn({ name: 'acteur_reassureur_id' })
  acteurReassureur!: Acteur;
  @Column({ name: 'acteur_reassureur_id' })
  acteurReassureurId!: number;


// Relation courtier
  @ManyToOne(() => Acteur, {  eager:true , nullable:true})
  @JoinColumn({ name: 'acteur_courtier_id' })
  acteurCourtier?: Acteur;
  @Column({ name: 'acteur_courtier_id', nullable: true })
  acteurCourtierId?: number;

}
