import { Controller, Param, ParseIntPipe, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CrudController } from 'src/common/crud/crud.controller';
import { FindManyOptions, IsNull } from 'typeorm';
import { CreatePoliceRetroCessionDto } from 'src/polices/dto/create-police-cession.dto';
import { UpdatePoliceRetroCessionDto } from 'src/polices/dto/update-police-cession.dto';
import { PoliceRetroCession } from '../entities/police-retro-cession.entity';
import { PoliceRetroCessionService } from '../services/police-retro-cession.service';

@ApiTags('PoliceRetroCession')
@Controller('police-reto-cession')
export class PoliceRetroCessionController extends 
CrudController<PoliceRetroCession, CreatePoliceRetroCessionDto, UpdatePoliceRetroCessionDto> {
  constructor(protected readonly service: PoliceRetroCessionService) {
    super(service);
  }
     // les diffentes options ou filtre pour 
      protected buildOptions(query: any): FindManyOptions<PoliceRetroCession> {        
            console.log("_____________________________________")
            console.log("PoliceRetroCessionController.buildOptions")
            console.log("query:",query)
            console.log("_____________________________________")
            
            const options: FindManyOptions<PoliceRetroCession> = {
              where: {},
              order: {}, 
            };
            const baseSort: any = { createdAt: 'desc'  };// Tri par défaut
            if( query.sortKey && query.sortDirection){
                options.order ={ [query.sortKey]: `${query.sortDirection}`}
            }else {
              options.order = baseSort
            }   

            //  Filtres exacts (AND)
            const baseWhere: any = {};
              // 2. Gestion du filtre assureId (null ou valeur spécifique)
            if ( !query.assureId || query.assureId === 'null' || query.assureId === null) {
              // Filtre pour récupérer les polices SANS assure
              baseWhere.assure = IsNull(); 
              
            } else if (query.assureId) {
              // Filtre pour un assure spécifique
              baseWhere.assure = { id: parseInt(query.assureId, 10) };               
            }

            if (query.isCession ) {
              baseWhere.isCession = query.isCession==='true';
            }  
             if (query.isFac ) {
              baseWhere.isFac = query.isFac==='true';
            } 


            console.log("baseWhere:",baseWhere)
            options.where = baseWhere

            console.log("options:",options)
            console.log("_____________________________________")
          
            return options;
      }

    
}
