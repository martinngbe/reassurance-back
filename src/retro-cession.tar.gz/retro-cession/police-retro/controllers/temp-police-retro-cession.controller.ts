import { Controller, Param, ParseIntPipe, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CrudController } from 'src/common/crud/crud.controller';
import { FindManyOptions } from 'typeorm';
import { TempPoliceRetroCession } from '../entities/temp-police-retro-cession.entity';
import { CreateTempPoliceRetroCessionDto } from 'src/polices/dto/create-temp-police-cession.dto';
import { UpdateTempPoliceRetroCessionDto } from 'src/polices/dto/update-temp-police-cession.dto';
import { TempPoliceRetroCessionService } from '../services/temp-police-retro-cession.service';

@ApiTags('TempPolice')
@Controller('temp-police')
export class TempPoliceRetroCessionController extends
 CrudController<TempPoliceRetroCession, CreateTempPoliceRetroCessionDto, UpdateTempPoliceRetroCessionDto> {
  constructor(protected readonly service: TempPoliceRetroCessionService) {
    super(service);
  }
     // les diffentes options ou filtre pour 
      protected buildOptions(query: any): FindManyOptions<TempPoliceRetroCession> {        
            console.log("_____________________________________")
            console.log("TempPoliceController.buildOptions")
            console.log("query:",query)
            console.log("_____________________________________")
            
            const options: FindManyOptions<TempPoliceRetroCession> = {
              where: {},
              order: {}, 
            };
            const baseSort: any = { createdAt: 'DESC'  };// Tri par défaut
            if( query.sortKey && query.sortDirection){
                options.order ={ [query.sortKey]: `${query.sortDirection}`}
            }else {
              options.order = baseSort
            }   

            // filtre sur un champs spécifique; Tableau de conditions
            const baseWhere: any = {};
            if (query.acteurId) {
              baseWhere.acteur = { id: parseInt(query.acteurId, 10) }; 
            }
            if (query.assureId) {
              baseWhere.assure = { id: parseInt(query.assureId, 10) }; 
            }
            
            options.where = baseWhere

            console.log("options:",options)
            console.log("_____________________________________")
            
            return options;
      }


}
