import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ClsModule } from 'nestjs-cls';
import { PoliceRetroCession } from './entities/police-retro-cession.entity';
import { TempPoliceRetroCession } from './entities/temp-police-retro-cession.entity';
import { PoliceRetroCessionController } from './controllers/police-retro.controller';
import { PoliceRetroCessionService } from './services/police-retro-cession.service';
import { TempPoliceRetroCessionService } from './services/temp-police-retro-cession.service';
import { TempPoliceRetroCessionController } from './controllers/temp-police-retro-cession.controller';

@Module({
  
  imports: [
     ClsModule, // ⬅️ OBLIGATOIRE pour @Transactional pour que le CLS fonctionne dans ce module
    TypeOrmModule.forFeature([PoliceRetroCession , TempPoliceRetroCession])],
  controllers: [PoliceRetroCessionController , TempPoliceRetroCessionController],
  providers: [PoliceRetroCessionService , TempPoliceRetroCessionService],
  exports: [PoliceRetroCessionService,TempPoliceRetroCessionService],
})
export class PoliceRetroCessionModule {}
