import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';


import { ClsModule } from 'nestjs-cls';
import { FluxFinancierModule } from 'src/flux-financier/flux-financier.module';
import { EcheancePmd } from 'src/flux-financier/entities/echeance-pmd.entity';
import { QuittanceRetroCession } from './entities/quittance-retro-cession.entity';
import { TempQuittanceRetroCession } from './entities/temp-quittance-retro-cession.entity';
import { QuittanceRetroCessionService } from './services/quittance-retro-cession.service';
import { TempQuittanceRetroCessionService } from './services/temp-quittance-retro-cession.service';
import { QuittanceRetroCessionController } from './controllers/quittance-retro-cession.controller';
import { TempQuittanceRetroCessionController } from './controllers/temp-quittance-retro-cession.controller';

/**
 * Cœur métier "Affaires" : quittances d'acceptation, leurs rétrocessions
 * (QuittancePlacement), les objets assurés et les échéances PMD.
 * ObjetAssure n'a pas de route dédiée : il est géré comme sous-ressource
 * de la quittance (ajouter un ObjetAssureController si besoin d'un accès
 * direct, en suivant le même patron CrudController).
 */
@Module({
  imports: [
    ClsModule, // ⬅️ OBLIGATOIRE pour @Transactional pour que le CLS fonctionne dans ce module    
    FluxFinancierModule,
    TypeOrmModule.forFeature([
      QuittanceRetroCession, 
      EcheancePmd,
      TempQuittanceRetroCession,
    ]),
  ],
  controllers: [
    QuittanceRetroCessionController, 
    TempQuittanceRetroCessionController,
    
  ],
  providers: [
    QuittanceRetroCessionService, 
    TempQuittanceRetroCessionService,
  ],
  exports: [
    QuittanceRetroCessionService,
    TempQuittanceRetroCessionService,
  ],
})
export class QuittancesRetroCessionModule {}
