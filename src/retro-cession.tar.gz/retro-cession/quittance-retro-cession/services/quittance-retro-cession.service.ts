import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { QuittanceRetroCession } from '../entities/quittance-retro-cession.entity';
import { CrudService } from 'src/common/crud/crud.service';

@Injectable()
export class QuittanceRetroCessionService 
extends CrudService<QuittanceRetroCession> {
  constructor(@InjectRepository(QuittanceRetroCession) 
  repository: Repository<QuittanceRetroCession>) {
    super(repository);
  }
 
}