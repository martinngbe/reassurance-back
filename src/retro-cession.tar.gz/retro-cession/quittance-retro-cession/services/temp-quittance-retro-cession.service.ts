import {  Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CrudService } from 'src/common/crud/crud.service';
import { TempQuittanceRetroCession } from '../entities/temp-quittance-retro-cession.entity';

@Injectable()
export class TempQuittanceRetroCessionService 
 extends CrudService<TempQuittanceRetroCession>{
  constructor(
    @InjectRepository(TempQuittanceRetroCession)
    private tempQuittanceRepository: Repository<TempQuittanceRetroCession>,
   
  ) {super(tempQuittanceRepository);}
}