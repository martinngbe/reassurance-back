import {
  IsBoolean,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class CreateTempQuittanceRetroCessionDto {
  @IsString()
  @IsNotEmpty()
  numero!: string;

  @IsInt()
  @IsNotEmpty()
  mouvementId!: number;

  @IsInt()
  @IsNotEmpty()
  policeRetroCessionId!: number;

  @IsInt()
  @IsNotEmpty()
  deviseId!: number;

  @IsBoolean()
  @IsOptional()
  isCession?: boolean;

  @IsBoolean()
  @IsOptional()
  isProportionnel?: boolean;

  @IsBoolean()
  @IsOptional()
  isFac?: boolean;

  @IsDateString()
  dateEmission!: string;

  @IsDateString()
  @IsOptional()
  dateEffet!: string;

  @IsDateString()
  @IsOptional()
  dateEcheance!: string;

  @IsNumber()
  @IsNotEmpty()
  coursDevise: number=1;

  @IsInt()
  @IsOptional()
  avisEcheance!: number;

  @IsNumber()
  capitaux: number=0;

  @IsNumber()
  nombrePlein: number=0;

  @IsNumber()
  lci: number=0;

  @IsNumber()
  smp: number=0;

  @IsNumber()
  limite: number=0;

  @IsNumber()
  retention: number=0;

  @IsNumber()
  conservation: number=0;

  @IsNumber()
  capacite: number=0;

  @IsNumber()
  estimationPrime: number=0;

  @IsNumber()
  tauxCedante: number=0;

  @IsNumber()
  tauxAccepte: number=0;

  @IsNumber()
  tauxCommission: number=0;

  @IsNumber()
  taxeSurCommission: number=0;

  @IsNumber()
  tauxCession: number = 0;

  @IsNumber()
  tauxRetention: number = 0;



  @IsNumber()
  primeBrute: number=0;

  @IsNumber()
  primeNette: number=0;

  @IsNumber()
  taxeSurPrime: number=0;

  @IsInt()
  nombreEcheancePmd: number=0;

  @IsNumber()
  @IsOptional()
  sinistreAuComptant?: number;

  @IsNumber()
  @IsOptional()
  avisSinistre?: number;

  @IsNumber()
  @IsOptional()
  aliment?: number;

}
