import { PartialType } from '@nestjs/mapped-types';
import {  CreateQuittanceRetroCessionDto } from './create-quittance-retro-cession.dto';

export class UpdateQuittanceRetroCessionDto 
extends PartialType(CreateQuittanceRetroCessionDto) {}
