import { PartialType } from '@nestjs/mapped-types';
import { CreateTempQuittanceRetroCessionDto } from './create-temp-quittance-retro-cession.dto';

export class UpdateTempQuittanceRetroCessionDto 
extends PartialType(CreateTempQuittanceRetroCessionDto) {}
