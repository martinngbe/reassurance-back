import {
  Controller, Get,  Param,  ParseIntPipe,  Patch,
} from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';

import { CrudController } from 'src/common/crud/crud.controller';
import { FindManyOptions } from 'typeorm';
import { QuittanceRetroCession } from '../entities/quittance-retro-cession.entity';
import { CreateQuittanceRetroCessionDto } from '../dto/create-quittance-retro-cession.dto';
import { UpdateQuittanceRetroCessionDto } from '../dto/update-quittance-retro-cesion.dto';
import { QuittanceRetroCessionService } from '../services/quittance-retro-cession.service';

@ApiTags('Métier Affaires - Quittances')
@Controller('quittance')
export class QuittanceRetroCessionController
 extends CrudController<QuittanceRetroCession,
  CreateQuittanceRetroCessionDto,
   UpdateQuittanceRetroCessionDto> {
  constructor(private readonly quittanceService: 
    QuittanceRetroCessionService) 
  {  super(quittanceService);}

   // les quittances seront affichées par ordre de la plus récentes
   protected buildOptions(query: any): FindManyOptions<QuittanceRetroCession> {
      const options: FindManyOptions<QuittanceRetroCession> = {
        where: {},
        order: {}, // Tri par défaut
      };
      const baseSort: any = { createdAt: 'DESC'  };// Tri par défaut
      if( query.sortKey && query.sortDirection){
          options.order ={ [query.sortKey]: `${query.sortDirection}`}
      }else {
        options.order = baseSort
      }   

      // filtre sur un champs spécifique; Tableau de conditions
      const baseWhere: any = {};
      if (query.policeId) {
        baseWhere.police = { id: parseInt(query.policeId, 10) }; 
      }
    
      
      options.where = baseWhere

      console.log("options:",options)
      console.log("_____________________________________")

      return options;
    }
  

}