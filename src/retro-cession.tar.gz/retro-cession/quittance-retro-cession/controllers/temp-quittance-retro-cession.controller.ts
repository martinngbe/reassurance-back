import {
  Controller,
} from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';

import { CrudController } from 'src/common/crud/crud.controller';
import { FindManyOptions } from 'typeorm';
import { CreateTempQuittanceRetroCessionDto } from '../dto/create-temp-quittance-retro-cession.dto';
import { TempQuittanceRetroCession } from '../entities/temp-quittance-retro-cession.entity';
import { UpdateTempQuittanceRetroCessionDto } from '../dto/update-temp-quittance-retro-cession.dto';
import { TempQuittanceRetroCessionService } from '../services/temp-quittance-retro-cession.service';

@ApiTags('Métier Affaires - TempTempQuittances')
@Controller('temp-quittance-retro-cession')
export class TempQuittanceRetroCessionController 
extends CrudController<TempQuittanceRetroCession, 
CreateTempQuittanceRetroCessionDto, 
UpdateTempQuittanceRetroCessionDto> {
  constructor(private readonly quittanceService: TempQuittanceRetroCessionService) 
  {  super(quittanceService);}

   // les quittances seront affichées par ordre de la plus récentes
   protected buildOptions(query: any): FindManyOptions<TempQuittanceRetroCession> {
      const options: FindManyOptions<TempQuittanceRetroCession> = {
        where: {},
        order: { createdAt: 'DESC' }, // Tri par défaut
      };
      return options;
    }
  

}